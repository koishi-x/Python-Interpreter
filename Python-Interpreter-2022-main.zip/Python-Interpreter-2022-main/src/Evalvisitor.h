#ifndef PYTHON_INTERPRETER_EVALVISITOR_H
#define PYTHON_INTERPRETER_EVALVISITOR_H


#include "Python3BaseVisitor.h"


class EvalVisitor: public Python3BaseVisitor {

//todo:override all methods of Python3BaseVisitor
};


#endif //PYTHON_INTERPRETER_EVALVISITOR_H
